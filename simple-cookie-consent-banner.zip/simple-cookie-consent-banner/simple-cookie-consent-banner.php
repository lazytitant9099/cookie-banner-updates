<?php
/**
 * Plugin Name: Modernvisuals Cookie Consent Banner
 * Plugin URI: https://example.com/simple-cookie-consent-banner
 * Description: A category-based, GDPR-compliant cookie consent banner with tracking integrations and cookie discovery. No external dependencies.
 * Version: 2.3.1
 * Author: Modern Visuals
 * Author URI: https://modernvisuals.nl
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: simple-cookie-consent-banner
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Plugin constants
define( 'SCCB_VERSION', '2.3.1' );
define( 'SCCB_DB_VERSION', '1.0' );
define( 'SCCB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SCCB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SCCB_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'SCCB_UPDATE_URL', 'https://raw.githubusercontent.com/lazytitant9099/cookie-banner-updates/main/info.json' );

/**
 * Cookie categories definition.
 */
function sccb_get_cookie_categories(): array {
    return [
        'necessary'  => [
            'label'       => 'Noodzakelijk',
            'description' => 'Deze cookies zijn essentieel voor het functioneren van de website.',
            'required'    => true,
        ],
        'functional' => [
            'label'       => 'Functioneel',
            'description' => 'Deze cookies maken verbeterde functionaliteit en personalisatie mogelijk.',
            'required'    => false,
        ],
        'analytics'  => [
            'label'       => 'Analytisch',
            'description' => 'Deze cookies helpen ons te begrijpen hoe bezoekers de website gebruiken.',
            'required'    => false,
        ],
        'marketing'  => [
            'label'       => 'Marketing',
            'description' => 'Deze cookies worden gebruikt om relevante advertenties te tonen.',
            'required'    => false,
        ],
    ];
}

/**
 * Get default plugin options.
 *
 * @return array Default options array.
 */
function sccb_get_default_options(): array {
    return [
        // General
        'enabled'                   => false,
        'banner_text'               => 'Wij gebruiken cookies om je ervaring te verbeteren. Kies hieronder welke cookies je wilt accepteren.',
        'privacy_policy_url'        => '',
        
        // Button labels
        'accept_all_label'          => 'Alles accepteren',
        'accept_selected_label'     => 'Selectie opslaan',
        'reject_all_label'          => 'Alles weigeren',
        'settings_label'            => 'Meer opties',
        
        // Category labels (customizable)
        'category_necessary_label'  => 'Noodzakelijk',
        'category_necessary_desc'   => 'Deze cookies zijn essentieel voor het functioneren van de website en kunnen niet worden uitgeschakeld.',
        'category_functional_label' => 'Functioneel',
        'category_functional_desc'  => 'Deze cookies maken verbeterde functionaliteit en personalisatie mogelijk.',
        'category_analytics_label'  => 'Analytisch',
        'category_analytics_desc'   => 'Deze cookies helpen ons te begrijpen hoe bezoekers de website gebruiken.',
        'category_marketing_label'  => 'Marketing',
        'category_marketing_desc'   => 'Deze cookies worden gebruikt om relevante advertenties te tonen.',
        
        // Tracking IDs
        'ga4_measurement_id'        => '',
        'gtm_container_id'          => '',
        'meta_pixel_id'             => '',
        'hotjar_site_id'            => '',
        
        // Styling
        'background_color'          => '#1a202c',
        'text_color'                => '#e2e8f0',
        'button_primary_color'      => '#48bb78',
        'button_secondary_color'    => '#4a5568',
        'accent_color'              => '#667eea',
        'position'                  => 'bottom',
        'layout'                    => 'bar', // 'bar' or 'modal'
    ];
}

/**
 * Get plugin options with defaults.
 *
 * @return array Merged options array.
 */
function sccb_get_options(): array {
    $defaults = sccb_get_default_options();
    $options  = get_option( 'sccb_options', [] );
    
    return wp_parse_args( $options, $defaults );
}

/**
 * Get discovered cookies.
 *
 * @return array Discovered cookies array.
 */
function sccb_get_discovered_cookies(): array {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sccb_cookies';
    
    // Check if table exists first to avoid errors during installation/activation
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) !== $table_name ) {
        return get_option( 'sccb_discovered_cookies', [] );
    }

    $results = $wpdb->get_results( "SELECT * FROM $table_name ORDER BY name ASC", ARRAY_A );
    
    $cookies = [];
    if ( ! empty( $results ) ) {
        foreach ( $results as $row ) {
            $cookies[ $row['name'] ] = [
                'name'        => $row['name'],
                'category'    => $row['category'],
                'description' => $row['description'],
                'first_seen'  => $row['first_seen'],
                'last_seen'   => $row['last_seen'],
            ];
        }
    }
    
    return $cookies;
}

/**
 * Create or update the database table.
 */
function sccb_install_db(): void {
    global $wpdb;
    $table_name = $wpdb->prefix . 'sccb_cookies';
    
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        category varchar(50) DEFAULT 'functional' NOT NULL,
        description text DEFAULT '' NOT NULL,
        first_seen datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        last_seen datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY name (name)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );

    add_option( 'sccb_db_version', SCCB_DB_VERSION );
    
    // Migrate old data if exists
    $old_cookies = get_option( 'sccb_discovered_cookies' );
    if ( ! empty( $old_cookies ) && is_array( $old_cookies ) ) {
        foreach ( $old_cookies as $name => $data ) {
            $wpdb->replace(
                $table_name,
                [
                    'name'        => sanitize_text_field( $name ),
                    'category'    => sanitize_key( $data['category'] ?? 'functional' ),
                    'description' => sanitize_text_field( $data['description'] ?? '' ),
                    'first_seen'  => $data['first_seen'] ?? current_time( 'mysql' ),
                    'last_seen'   => $data['last_seen'] ?? current_time( 'mysql' ),
                ],
                [ '%s', '%s', '%s', '%s', '%s' ]
            );
        }
        // Rename old option to prevent re-migration but keep as backup
        update_option( 'sccb_discovered_cookies_backup', $old_cookies );
        delete_option( 'sccb_discovered_cookies' );
    }
}

/**
 * Check DB version and update if necessary.
 */
function sccb_update_db_check(): void {
    if ( get_option( 'sccb_db_version' ) !== SCCB_DB_VERSION ) {
        sccb_install_db();
    }
}
add_action( 'plugins_loaded', 'sccb_update_db_check' );

/**
 * Activation hook - set transient for redirect and install DB.
 */
function sccb_activate(): void {
    sccb_install_db();
    if ( false === get_option( 'sccb_options' ) ) {
        set_transient( 'sccb_activation_redirect', true, 30 );
    }
}
register_activation_hook( __FILE__, 'sccb_activate' );

/**
 * Redirect to setup wizard on first activation.
 */
function sccb_activation_redirect(): void {
    if ( ! get_transient( 'sccb_activation_redirect' ) ) {
        return;
    }
    
    delete_transient( 'sccb_activation_redirect' );
    
    if ( is_network_admin() || isset( $_GET['activate-multi'] ) ) {
        return;
    }
    
    wp_safe_redirect( admin_url( 'options-general.php?page=sccb-cookie-consent' ) );
    exit;
}
add_action( 'admin_init', 'sccb_activation_redirect' );

/**
 * Register admin menu under Settings.
 */
function sccb_register_admin_menu(): void {
    add_options_page(
        __( 'Cookie Consent', 'simple-cookie-consent-banner' ),
        __( 'Cookie Consent', 'simple-cookie-consent-banner' ),
        'manage_options',
        'sccb-cookie-consent',
        'sccb_render_admin_page'
    );
}
add_action( 'admin_menu', 'sccb_register_admin_menu' );

/**
 * Display admin notice if banner is not configured.
 */
function sccb_admin_notices(): void {
    $options = sccb_get_options();
    
    $screen = get_current_screen();
    if ( $screen && $screen->id === 'settings_page_sccb-cookie-consent' ) {
        return;
    }
    
    if ( false === get_option( 'sccb_options' ) || empty( $options['enabled'] ) ) {
        printf(
            '<div class="notice notice-warning is-dismissible"><p>%s <a href="%s">%s</a></p></div>',
            esc_html__( 'Simple Cookie Consent Banner is niet geconfigureerd.', 'simple-cookie-consent-banner' ),
            esc_url( admin_url( 'options-general.php?page=sccb-cookie-consent' ) ),
            esc_html__( 'Klik hier om te configureren.', 'simple-cookie-consent-banner' )
        );
    }
}
add_action( 'admin_notices', 'sccb_admin_notices' );

/**
 * Enqueue admin styles.
 *
 * @param string $hook Current admin page hook.
 */
function sccb_admin_enqueue_scripts( string $hook ): void {
    if ( 'settings_page_sccb-cookie-consent' !== $hook ) {
        return;
    }
    
    wp_add_inline_style( 'wp-admin', sccb_get_admin_styles() );
}
add_action( 'admin_enqueue_scripts', 'sccb_admin_enqueue_scripts' );

/**
 * Get admin wizard styles.
 *
 * @return string CSS styles.
 */
function sccb_get_admin_styles(): string {
    return '
        .sccb-wizard-wrap { max-width: 900px; margin: 20px 0; }
        .sccb-wizard-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 30px; border-radius: 8px 8px 0 0; }
        .sccb-wizard-header h1 { margin: 0 0 10px; color: #fff; font-size: 28px; }
        .sccb-wizard-header p { margin: 0; opacity: 0.9; font-size: 14px; }
        .sccb-step-indicator { display: flex; justify-content: space-between; padding: 15px 20px; background: #f8f9fa; border-left: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0; flex-wrap: wrap; gap: 10px; }
        .sccb-step-item { display: flex; align-items: center; gap: 6px; color: #718096; font-size: 12px; cursor: pointer; transition: color 0.2s; }
        .sccb-step-item:hover { color: #4a5568; }
        .sccb-step-item.active { color: #667eea; font-weight: 600; }
        .sccb-step-item.completed { color: #48bb78; }
        .sccb-step-number { width: 24px; height: 24px; border-radius: 50%; background: #e2e8f0; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 11px; }
        .sccb-step-item.active .sccb-step-number { background: #667eea; color: #fff; }
        .sccb-step-item.completed .sccb-step-number { background: #48bb78; color: #fff; }
        .sccb-wizard-content { background: #fff; padding: 30px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 8px 8px; }
        .sccb-step { display: none; }
        .sccb-step.active { display: block; }
        .sccb-step h2 { margin-top: 0; padding-bottom: 15px; border-bottom: 1px solid #e2e8f0; color: #2d3748; font-size: 20px; }
        .sccb-step h3 { color: #4a5568; font-size: 16px; margin: 25px 0 15px; padding-top: 15px; border-top: 1px solid #f0f0f0; }
        .sccb-step h3:first-of-type { margin-top: 20px; padding-top: 0; border-top: none; }
        .sccb-form-row { margin-bottom: 20px; }
        .sccb-form-row label { display: block; font-weight: 600; margin-bottom: 6px; color: #2d3748; font-size: 13px; }
        .sccb-form-row input[type="text"], .sccb-form-row input[type="color"], .sccb-form-row select, .sccb-form-row textarea { width: 100%; max-width: 500px; padding: 10px 12px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 14px; transition: border-color 0.2s; }
        .sccb-form-row input[type="text"]:focus, .sccb-form-row textarea:focus, .sccb-form-row select:focus { border-color: #667eea; outline: none; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
        .sccb-form-row input[type="color"] { width: 60px; height: 40px; padding: 4px; cursor: pointer; }
        .sccb-form-row textarea { max-width: 100%; min-height: 70px; resize: vertical; }
        .sccb-form-row .description { margin-top: 5px; color: #718096; font-size: 12px; }
        .sccb-form-row-inline { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
        .sccb-toggle-wrap { display: flex; align-items: center; gap: 12px; }
        .sccb-toggle { position: relative; width: 50px; height: 26px; flex-shrink: 0; }
        .sccb-toggle input { opacity: 0; width: 0; height: 0; }
        .sccb-toggle-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #cbd5e0; transition: 0.3s; border-radius: 26px; }
        .sccb-toggle-slider:before { position: absolute; content: ""; height: 20px; width: 20px; left: 3px; bottom: 3px; background-color: white; transition: 0.3s; border-radius: 50%; }
        .sccb-toggle input:checked + .sccb-toggle-slider { background-color: #48bb78; }
        .sccb-toggle input:checked + .sccb-toggle-slider:before { transform: translateX(24px); }
        .sccb-toggle-label { font-weight: 500; color: #4a5568; }
        .sccb-color-row { display: grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap: 15px; }
        .sccb-color-item { display: flex; flex-direction: column; gap: 6px; }
        .sccb-color-item label { font-weight: 500; font-size: 12px; }
        .sccb-color-input-wrap { display: flex; align-items: center; gap: 8px; }
        .sccb-color-input-wrap input[type="text"] { width: 90px; font-family: monospace; font-size: 12px; padding: 8px; }
        .sccb-wizard-nav { display: flex; justify-content: space-between; margin-top: 25px; padding-top: 20px; border-top: 1px solid #e2e8f0; }
        .sccb-wizard-nav .button { padding: 8px 20px; height: auto; }
        .sccb-summary-table { width: 100%; border-collapse: collapse; font-size: 13px; }
        .sccb-summary-table th, .sccb-summary-table td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
        .sccb-summary-table th { background: #f8f9fa; font-weight: 600; width: 35%; }
        .sccb-summary-table td { color: #4a5568; }
        .sccb-color-preview { display: inline-block; width: 16px; height: 16px; border-radius: 3px; vertical-align: middle; margin-right: 6px; border: 1px solid #e2e8f0; }
        .sccb-success-message { background: #f0fff4; border: 1px solid #9ae6b4; border-radius: 8px; padding: 20px; text-align: center; margin-bottom: 20px; }
        .sccb-success-message .dashicons { font-size: 40px; width: 40px; height: 40px; color: #48bb78; }
        .sccb-success-message h3 { margin: 10px 0 5px; color: #276749; font-size: 18px; }
        .sccb-success-message p { color: #48bb78; margin: 0; font-size: 13px; }
        .sccb-category-box { background: #f8f9fa; border: 1px solid #e2e8f0; border-radius: 6px; padding: 15px; margin-bottom: 15px; }
        .sccb-category-box h4 { margin: 0 0 10px; color: #2d3748; font-size: 14px; display: flex; align-items: center; gap: 8px; }
        .sccb-category-box h4 .badge { font-size: 10px; background: #667eea; color: #fff; padding: 2px 6px; border-radius: 3px; font-weight: 500; }
        .sccb-category-box h4 .badge-required { background: #e53e3e; }
        .sccb-tracking-box { background: #fff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 15px; margin-bottom: 15px; }
        .sccb-tracking-box h4 { margin: 0 0 12px; color: #2d3748; font-size: 14px; display: flex; align-items: center; gap: 8px; }
        .sccb-tracking-box h4 img { width: 20px; height: 20px; }
        .sccb-tracking-box .sccb-form-row { margin-bottom: 0; }
        .sccb-tracking-box .description { font-size: 11px; }
        .sccb-cookie-table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 15px; }
        .sccb-cookie-table th, .sccb-cookie-table td { padding: 10px; text-align: left; border: 1px solid #e2e8f0; }
        .sccb-cookie-table th { background: #f8f9fa; font-weight: 600; }
        .sccb-cookie-table select { padding: 6px 8px; font-size: 12px; border-radius: 4px; }
        .sccb-cookie-table input[type="text"] { padding: 6px 8px; font-size: 12px; width: 100%; max-width: none; }
        .sccb-no-cookies { color: #718096; font-style: italic; padding: 20px; text-align: center; background: #f8f9fa; border-radius: 6px; }
        .sccb-info-box { background: #ebf8ff; border: 1px solid #90cdf4; border-radius: 6px; padding: 12px 15px; margin-bottom: 20px; font-size: 13px; color: #2b6cb0; }
        .sccb-info-box strong { color: #2c5282; }
        .sccb-tabs { display: flex; gap: 0; margin-bottom: 20px; border-bottom: 2px solid #e2e8f0; }
        .sccb-tab { padding: 10px 20px; cursor: pointer; border: none; background: none; font-size: 13px; font-weight: 500; color: #718096; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all 0.2s; }
        .sccb-tab:hover { color: #4a5568; }
        .sccb-tab.active { color: #667eea; border-bottom-color: #667eea; }
        .sccb-tab-content { display: none; }
        .sccb-tab-content.active { display: block; }
    ';
}

/**
 * Register REST API endpoints for cookie discovery.
 */
function sccb_register_rest_routes(): void {
    register_rest_route( 'sccb/v1', '/cookies', [
        'methods'             => 'POST',
        'callback'            => 'sccb_handle_cookie_discovery',
        'permission_callback' => 'sccb_can_submit_cookie_discovery',
    ] );
}
add_action( 'rest_api_init', 'sccb_register_rest_routes' );

/**
 * Validate REST cookie discovery permissions via nonce.
 *
 * @param WP_REST_Request $request Request object.
 * @return bool|WP_Error
 */
function sccb_can_submit_cookie_discovery( WP_REST_Request $request ) {
    // Accept valid nonce
    $nonce = $request->get_header( 'x-wp-nonce' );
    if ( ! empty( $nonce ) && wp_verify_nonce( $nonce, 'wp_rest' ) ) {
        return true;
    }

    // For cached pages the nonce may be stale. This endpoint is low-risk
    // (it only writes cookie names), so allow with a same-origin referer check.
    $referer = wp_get_raw_referer();
    if ( $referer && strpos( $referer, home_url() ) === 0 ) {
        return true;
    }

    return new WP_Error(
        'sccb_forbidden',
        __( 'Ongeldige beveiligingssleutel.', 'simple-cookie-consent-banner' ),
        [ 'status' => 403 ]
    );
}

/**
 * Sanitize cookie names to avoid storing unexpected characters.
 *
 * @param string $name Raw cookie name.
 * @return string Sanitized cookie name.
 */
function sccb_sanitize_cookie_name( string $name ): string {
    $name = sanitize_text_field( $name );
    $name = preg_replace( '/[^\w\.\-\|:]/', '', $name );

    return substr( $name, 0, 64 );
}

/**
 * Get the client's real IP address, accounting for reverse proxies.
 *
 * @return string Client IP address.
 */
function sccb_get_client_ip(): string {
    $headers = [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP' ];
    foreach ( $headers as $header ) {
        if ( ! empty( $_SERVER[ $header ] ) ) {
            $ip = $_SERVER[ $header ];
            if ( strpos( $ip, ',' ) !== false ) {
                $ip = trim( explode( ',', $ip )[0] );
            }
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                return $ip;
            }
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

/**
 * Simple per-IP rate limit for cookie discovery submissions.
 *
 * @return bool True when the caller exceeded the limit.
 */
function sccb_is_cookie_discovery_rate_limited(): bool {
    $ip          = sccb_get_client_ip();
    $cache_key   = 'sccb_cookie_discovery_' . md5( $ip );
    $submissions = (int) get_transient( $cache_key );

    if ( $submissions >= 20 ) {
        return true;
    }

    set_transient( $cache_key, $submissions + 1, MINUTE_IN_SECONDS * 5 );

    return false;
}

/**
 * Handle cookie discovery from frontend.
 *
 * @param WP_REST_Request $request Request object.
 * @return WP_REST_Response Response object.
 */
function sccb_handle_cookie_discovery( WP_REST_Request $request ): WP_REST_Response {
    global $wpdb;
    $cookies = $request->get_param( 'cookies' );

    if ( ! is_array( $cookies ) ) {
        return new WP_REST_Response( [ 'error' => 'Invalid data' ], 400 );
    }

    if ( sccb_is_cookie_discovery_rate_limited() ) {
        return new WP_REST_Response( [ 'error' => 'Too many requests' ], 429 );
    }

    $cookies = array_map( 'sccb_sanitize_cookie_name', $cookies );
    $cookies = array_filter( $cookies );
    $cookies = array_unique( $cookies );
    $cookies = array_slice( $cookies, 0, 50 );

    if ( empty( $cookies ) ) {
        return new WP_REST_Response( [ 'error' => 'No valid cookies supplied' ], 400 );
    }

    $table_name = $wpdb->prefix . 'sccb_cookies';
    $now        = current_time( 'mysql' );
    $count      = 0;

    foreach ( $cookies as $cookie_name ) {
        // Prepare values
        $name     = substr( $cookie_name, 0, 100 ); // Match DB limit
        $category = sccb_auto_categorize_cookie( $name );
        
        // Use INSERT ... ON DUPLICATE KEY UPDATE for atomic operations
        // If cookie exists, only update last_seen. If not, insert new row.
        $result = $wpdb->query( $wpdb->prepare(
            "INSERT INTO $table_name (name, category, first_seen, last_seen) 
            VALUES (%s, %s, %s, %s) 
            ON DUPLICATE KEY UPDATE last_seen = VALUES(last_seen)",
            $name,
            $category,
            $now,
            $now
        ) );
        
        if ( $result !== false ) {
            $count++;
        }
    }

    // Get current total count for response
    $total_count = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );

    return new WP_REST_Response( [ 'success' => true, 'count' => (int) $total_count ], 200 );
}

/**
 * Attempt to auto-categorize a cookie based on its name.
 *
 * @param string $cookie_name Cookie name.
 * @return string Category slug.
 */
function sccb_auto_categorize_cookie( string $cookie_name ): string {
    $name = strtolower( $cookie_name );
    
    // Analytics patterns
    $analytics_patterns = [ '_ga', '_gid', '_gat', 'gtm', 'analytics', 'hotjar', '_hj', '__hstc', 'hubspot' ];
    foreach ( $analytics_patterns as $pattern ) {
        if ( strpos( $name, $pattern ) !== false ) {
            return 'analytics';
        }
    }
    
    // Marketing patterns
    $marketing_patterns = [ '_fbp', '_fbc', 'fbclid', 'facebook', 'meta', 'pixel', 'ad_', 'ads_', '_gcl', 'gclid', '_ttp', 'tiktok', 'linkedin', '_li', 'pinterest', '_pin' ];
    foreach ( $marketing_patterns as $pattern ) {
        if ( strpos( $name, $pattern ) !== false ) {
            return 'marketing';
        }
    }
    
    // Functional patterns
    $functional_patterns = [ 'lang', 'language', 'currency', 'timezone', 'theme', 'font', 'accessibility' ];
    foreach ( $functional_patterns as $pattern ) {
        if ( strpos( $name, $pattern ) !== false ) {
            return 'functional';
        }
    }
    
    // Necessary patterns (WordPress, sessions, security)
    $necessary_patterns = [ 'wordpress', 'wp-', 'wp_', 'session', 'csrf', 'xsrf', 'nonce', 'logged_in', 'auth', 'secure' ];
    foreach ( $necessary_patterns as $pattern ) {
        if ( strpos( $name, $pattern ) !== false ) {
            return 'necessary';
        }
    }
    
    // Default to functional for unknown cookies
    return 'functional';
}

/**
 * Handle form submission and save options.
 */
function sccb_handle_form_submission(): void {
    if ( ! isset( $_POST['sccb_save_settings'] ) ) {
        return;
    }
    
    if ( ! isset( $_POST['sccb_nonce'] ) || ! wp_verify_nonce( $_POST['sccb_nonce'], 'sccb_save_settings' ) ) {
        wp_die( esc_html__( 'Beveiligingscontrole mislukt.', 'simple-cookie-consent-banner' ) );
    }
    
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'Je hebt geen toegang tot deze pagina.', 'simple-cookie-consent-banner' ) );
    }
    
    $defaults = sccb_get_default_options();
    
    $options = [
        // General
        'enabled'                   => isset( $_POST['sccb_enabled'] ),
        'banner_text'               => sanitize_textarea_field( wp_unslash( $_POST['sccb_banner_text'] ?? $defaults['banner_text'] ) ),
        'privacy_policy_url'        => esc_url_raw( wp_unslash( $_POST['sccb_privacy_policy_url'] ?? '' ) ),
        
        // Button labels
        'accept_all_label'          => sanitize_text_field( wp_unslash( $_POST['sccb_accept_all_label'] ?? $defaults['accept_all_label'] ) ),
        'accept_selected_label'     => sanitize_text_field( wp_unslash( $_POST['sccb_accept_selected_label'] ?? $defaults['accept_selected_label'] ) ),
        'reject_all_label'          => sanitize_text_field( wp_unslash( $_POST['sccb_reject_all_label'] ?? $defaults['reject_all_label'] ) ),
        'settings_label'            => sanitize_text_field( wp_unslash( $_POST['sccb_settings_label'] ?? $defaults['settings_label'] ) ),
        
        // Category labels
        'category_necessary_label'  => sanitize_text_field( wp_unslash( $_POST['sccb_category_necessary_label'] ?? $defaults['category_necessary_label'] ) ),
        'category_necessary_desc'   => sanitize_textarea_field( wp_unslash( $_POST['sccb_category_necessary_desc'] ?? $defaults['category_necessary_desc'] ) ),
        'category_functional_label' => sanitize_text_field( wp_unslash( $_POST['sccb_category_functional_label'] ?? $defaults['category_functional_label'] ) ),
        'category_functional_desc'  => sanitize_textarea_field( wp_unslash( $_POST['sccb_category_functional_desc'] ?? $defaults['category_functional_desc'] ) ),
        'category_analytics_label'  => sanitize_text_field( wp_unslash( $_POST['sccb_category_analytics_label'] ?? $defaults['category_analytics_label'] ) ),
        'category_analytics_desc'   => sanitize_textarea_field( wp_unslash( $_POST['sccb_category_analytics_desc'] ?? $defaults['category_analytics_desc'] ) ),
        'category_marketing_label'  => sanitize_text_field( wp_unslash( $_POST['sccb_category_marketing_label'] ?? $defaults['category_marketing_label'] ) ),
        'category_marketing_desc'   => sanitize_textarea_field( wp_unslash( $_POST['sccb_category_marketing_desc'] ?? $defaults['category_marketing_desc'] ) ),
        
        // Tracking IDs
        'ga4_measurement_id'        => sanitize_text_field( wp_unslash( $_POST['sccb_ga4_measurement_id'] ?? '' ) ),
        'gtm_container_id'          => sanitize_text_field( wp_unslash( $_POST['sccb_gtm_container_id'] ?? '' ) ),
        'meta_pixel_id'             => sanitize_text_field( wp_unslash( $_POST['sccb_meta_pixel_id'] ?? '' ) ),
        'hotjar_site_id'            => sanitize_text_field( wp_unslash( $_POST['sccb_hotjar_site_id'] ?? '' ) ),
        
        // Styling
        'background_color'          => sanitize_hex_color( wp_unslash( $_POST['sccb_background_color'] ?? '' ) ) ?: $defaults['background_color'],
        'text_color'                => sanitize_hex_color( wp_unslash( $_POST['sccb_text_color'] ?? '' ) ) ?: $defaults['text_color'],
        'button_primary_color'      => sanitize_hex_color( wp_unslash( $_POST['sccb_button_primary_color'] ?? '' ) ) ?: $defaults['button_primary_color'],
        'button_secondary_color'    => sanitize_hex_color( wp_unslash( $_POST['sccb_button_secondary_color'] ?? '' ) ) ?: $defaults['button_secondary_color'],
        'accent_color'              => sanitize_hex_color( wp_unslash( $_POST['sccb_accent_color'] ?? '' ) ) ?: $defaults['accent_color'],
        'position'                  => in_array( $_POST['sccb_position'] ?? '', [ 'bottom', 'top', 'center' ], true ) ? $_POST['sccb_position'] : 'bottom',
        'layout'                    => in_array( $_POST['sccb_layout'] ?? '', [ 'bar', 'modal' ], true ) ? $_POST['sccb_layout'] : 'bar',
    ];
    
    update_option( 'sccb_options', $options );
    
    // Handle cookie mappings
    if ( isset( $_POST['sccb_cookie_category'] ) && is_array( $_POST['sccb_cookie_category'] ) ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sccb_cookies';
        
        foreach ( $_POST['sccb_cookie_category'] as $cookie_name => $category ) {
            $cookie_name = sanitize_text_field( $cookie_name );
            $category    = sanitize_key( $category );
            $description = '';
            
            if ( isset( $_POST['sccb_cookie_description'][ $cookie_name ] ) ) {
                $description = sanitize_text_field( wp_unslash( $_POST['sccb_cookie_description'][ $cookie_name ] ) );
            }
            
            $wpdb->update(
                $table_name,
                [ 
                    'category'    => $category,
                    'description' => $description
                ],
                [ 'name' => $cookie_name ],
                [ '%s', '%s' ],
                [ '%s' ]
            );
        }
    }
    
    wp_safe_redirect( admin_url( 'options-general.php?page=sccb-cookie-consent&saved=1' ) );
    exit;
}
add_action( 'admin_init', 'sccb_handle_form_submission' );

/**
 * Render the admin settings page with wizard.
 */
function sccb_render_admin_page(): void {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    
    $options           = sccb_get_options();
    $discovered_cookies = sccb_get_discovered_cookies();
    $saved             = isset( $_GET['saved'] ) && $_GET['saved'] === '1';
    $categories        = sccb_get_cookie_categories();
    
    ?>
    <div class="wrap sccb-wizard-wrap">
        <div class="sccb-wizard-header">
            <h1><?php esc_html_e( 'Cookie Consent Banner', 'simple-cookie-consent-banner' ); ?></h1>
            <p><?php esc_html_e( 'Configureer je GDPR-conforme cookie banner met categorieën en tracking integraties.', 'simple-cookie-consent-banner' ); ?></p>
        </div>
        
        <div class="sccb-step-indicator">
            <div class="sccb-step-item active" data-step="1">
                <span class="sccb-step-number">1</span>
                <span><?php esc_html_e( 'Algemeen', 'simple-cookie-consent-banner' ); ?></span>
            </div>
            <div class="sccb-step-item" data-step="2">
                <span class="sccb-step-number">2</span>
                <span><?php esc_html_e( 'Categorieën', 'simple-cookie-consent-banner' ); ?></span>
            </div>
            <div class="sccb-step-item" data-step="3">
                <span class="sccb-step-number">3</span>
                <span><?php esc_html_e( 'Tracking', 'simple-cookie-consent-banner' ); ?></span>
            </div>
            <div class="sccb-step-item" data-step="4">
                <span class="sccb-step-number">4</span>
                <span><?php esc_html_e( 'Cookies', 'simple-cookie-consent-banner' ); ?></span>
            </div>
            <div class="sccb-step-item" data-step="5">
                <span class="sccb-step-number">5</span>
                <span><?php esc_html_e( 'Styling', 'simple-cookie-consent-banner' ); ?></span>
            </div>
            <div class="sccb-step-item" data-step="6">
                <span class="sccb-step-number">6</span>
                <span><?php esc_html_e( 'Overzicht', 'simple-cookie-consent-banner' ); ?></span>
            </div>
        </div>
        
        <div class="sccb-wizard-content">
            <?php if ( $saved ) : ?>
                <div class="sccb-success-message">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <h3><?php esc_html_e( 'Instellingen opgeslagen!', 'simple-cookie-consent-banner' ); ?></h3>
                    <p><?php esc_html_e( 'Je cookie consent banner is bijgewerkt.', 'simple-cookie-consent-banner' ); ?></p>
                </div>
            <?php endif; ?>
            
            <form method="post" action="" id="sccb-wizard-form">
                <?php wp_nonce_field( 'sccb_save_settings', 'sccb_nonce' ); ?>
                
                <!-- Step 1: General Settings -->
                <div class="sccb-step active" data-step="1">
                    <h2><?php esc_html_e( 'Stap 1: Algemene instellingen', 'simple-cookie-consent-banner' ); ?></h2>
                    
                    <div class="sccb-form-row">
                        <div class="sccb-toggle-wrap">
                            <label class="sccb-toggle">
                                <input type="checkbox" name="sccb_enabled" value="1" <?php checked( $options['enabled'], true ); ?>>
                                <span class="sccb-toggle-slider"></span>
                            </label>
                            <span class="sccb-toggle-label"><?php esc_html_e( 'Cookie banner inschakelen', 'simple-cookie-consent-banner' ); ?></span>
                        </div>
                        <p class="description"><?php esc_html_e( 'Schakel de cookie consent banner in of uit op je website.', 'simple-cookie-consent-banner' ); ?></p>
                    </div>
                    
                    <div class="sccb-form-row">
                        <label for="sccb_banner_text"><?php esc_html_e( 'Banner tekst', 'simple-cookie-consent-banner' ); ?></label>
                        <textarea name="sccb_banner_text" id="sccb_banner_text" rows="3"><?php echo esc_textarea( $options['banner_text'] ); ?></textarea>
                        <p class="description"><?php esc_html_e( 'De hoofdtekst die bezoekers zien in de cookie banner.', 'simple-cookie-consent-banner' ); ?></p>
                    </div>
                    
                    <div class="sccb-form-row">
                        <label for="sccb_privacy_policy_url"><?php esc_html_e( 'Privacybeleid URL', 'simple-cookie-consent-banner' ); ?></label>
                        <input type="text" name="sccb_privacy_policy_url" id="sccb_privacy_policy_url" value="<?php echo esc_url( $options['privacy_policy_url'] ); ?>" placeholder="https://...">
                        <p class="description"><?php esc_html_e( 'Link naar je privacybeleid (optioneel).', 'simple-cookie-consent-banner' ); ?></p>
                    </div>
                    
                    <h3><?php esc_html_e( 'Knopteksten', 'simple-cookie-consent-banner' ); ?></h3>
                    
                    <div class="sccb-form-row-inline">
                        <div class="sccb-form-row">
                            <label for="sccb_accept_all_label"><?php esc_html_e( 'Alles accepteren', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_accept_all_label" id="sccb_accept_all_label" value="<?php echo esc_attr( $options['accept_all_label'] ); ?>">
                        </div>
                        <div class="sccb-form-row">
                            <label for="sccb_reject_all_label"><?php esc_html_e( 'Alles weigeren', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_reject_all_label" id="sccb_reject_all_label" value="<?php echo esc_attr( $options['reject_all_label'] ); ?>">
                        </div>
                    </div>
                    
                    <div class="sccb-form-row-inline">
                        <div class="sccb-form-row">
                            <label for="sccb_accept_selected_label"><?php esc_html_e( 'Selectie opslaan', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_accept_selected_label" id="sccb_accept_selected_label" value="<?php echo esc_attr( $options['accept_selected_label'] ); ?>">
                        </div>
                        <div class="sccb-form-row">
                            <label for="sccb_settings_label"><?php esc_html_e( 'Instellingen knop', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_settings_label" id="sccb_settings_label" value="<?php echo esc_attr( $options['settings_label'] ); ?>">
                        </div>
                    </div>
                </div>
                
                <!-- Step 2: Categories -->
                <div class="sccb-step" data-step="2">
                    <h2><?php esc_html_e( 'Stap 2: Cookie categorieën', 'simple-cookie-consent-banner' ); ?></h2>
                    <p class="description" style="margin-bottom: 20px;"><?php esc_html_e( 'Pas de labels en beschrijvingen van de cookie categorieën aan.', 'simple-cookie-consent-banner' ); ?></p>
                    
                    <div class="sccb-category-box">
                        <h4><?php esc_html_e( 'Noodzakelijk', 'simple-cookie-consent-banner' ); ?> <span class="badge badge-required"><?php esc_html_e( 'Verplicht', 'simple-cookie-consent-banner' ); ?></span></h4>
                        <div class="sccb-form-row">
                            <label for="sccb_category_necessary_label"><?php esc_html_e( 'Label', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_category_necessary_label" id="sccb_category_necessary_label" value="<?php echo esc_attr( $options['category_necessary_label'] ); ?>">
                        </div>
                        <div class="sccb-form-row">
                            <label for="sccb_category_necessary_desc"><?php esc_html_e( 'Beschrijving', 'simple-cookie-consent-banner' ); ?></label>
                            <textarea name="sccb_category_necessary_desc" id="sccb_category_necessary_desc" rows="2"><?php echo esc_textarea( $options['category_necessary_desc'] ); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="sccb-category-box">
                        <h4><?php esc_html_e( 'Functioneel', 'simple-cookie-consent-banner' ); ?></h4>
                        <div class="sccb-form-row">
                            <label for="sccb_category_functional_label"><?php esc_html_e( 'Label', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_category_functional_label" id="sccb_category_functional_label" value="<?php echo esc_attr( $options['category_functional_label'] ); ?>">
                        </div>
                        <div class="sccb-form-row">
                            <label for="sccb_category_functional_desc"><?php esc_html_e( 'Beschrijving', 'simple-cookie-consent-banner' ); ?></label>
                            <textarea name="sccb_category_functional_desc" id="sccb_category_functional_desc" rows="2"><?php echo esc_textarea( $options['category_functional_desc'] ); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="sccb-category-box">
                        <h4><?php esc_html_e( 'Analytisch', 'simple-cookie-consent-banner' ); ?></h4>
                        <div class="sccb-form-row">
                            <label for="sccb_category_analytics_label"><?php esc_html_e( 'Label', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_category_analytics_label" id="sccb_category_analytics_label" value="<?php echo esc_attr( $options['category_analytics_label'] ); ?>">
                        </div>
                        <div class="sccb-form-row">
                            <label for="sccb_category_analytics_desc"><?php esc_html_e( 'Beschrijving', 'simple-cookie-consent-banner' ); ?></label>
                            <textarea name="sccb_category_analytics_desc" id="sccb_category_analytics_desc" rows="2"><?php echo esc_textarea( $options['category_analytics_desc'] ); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="sccb-category-box">
                        <h4><?php esc_html_e( 'Marketing', 'simple-cookie-consent-banner' ); ?></h4>
                        <div class="sccb-form-row">
                            <label for="sccb_category_marketing_label"><?php esc_html_e( 'Label', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_category_marketing_label" id="sccb_category_marketing_label" value="<?php echo esc_attr( $options['category_marketing_label'] ); ?>">
                        </div>
                        <div class="sccb-form-row">
                            <label for="sccb_category_marketing_desc"><?php esc_html_e( 'Beschrijving', 'simple-cookie-consent-banner' ); ?></label>
                            <textarea name="sccb_category_marketing_desc" id="sccb_category_marketing_desc" rows="2"><?php echo esc_textarea( $options['category_marketing_desc'] ); ?></textarea>
                        </div>
                    </div>
                </div>
                
                <!-- Step 3: Tracking -->
                <div class="sccb-step" data-step="3">
                    <h2><?php esc_html_e( 'Stap 3: Tracking scripts', 'simple-cookie-consent-banner' ); ?></h2>
                    
                    <div class="sccb-info-box">
                        <strong><?php esc_html_e( 'Automatische integratie', 'simple-cookie-consent-banner' ); ?></strong><br>
                        <?php esc_html_e( 'Voer je tracking IDs in en de scripts worden automatisch geladen wanneer de gebruiker toestemming geeft voor de betreffende categorie.', 'simple-cookie-consent-banner' ); ?>
                    </div>
                    
                    <div class="sccb-tracking-box">
                        <h4>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="#F9AB00"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                            Google Analytics 4
                            <span class="badge"><?php esc_html_e( 'Analytisch', 'simple-cookie-consent-banner' ); ?></span>
                        </h4>
                        <div class="sccb-form-row">
                            <label for="sccb_ga4_measurement_id"><?php esc_html_e( 'Measurement ID', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_ga4_measurement_id" id="sccb_ga4_measurement_id" value="<?php echo esc_attr( $options['ga4_measurement_id'] ); ?>" placeholder="G-XXXXXXXXXX">
                            <p class="description"><?php esc_html_e( 'Je GA4 Measurement ID (begint met G-). Laat leeg als je Google Site Kit gebruikt.', 'simple-cookie-consent-banner' ); ?></p>
                        </div>
                    </div>
                    
                    <div class="sccb-tracking-box">
                        <h4>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="#4285F4"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/></svg>
                            Google Tag Manager
                            <span class="badge"><?php esc_html_e( 'Analytisch', 'simple-cookie-consent-banner' ); ?></span>
                        </h4>
                        <div class="sccb-form-row">
                            <label for="sccb_gtm_container_id"><?php esc_html_e( 'Container ID', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_gtm_container_id" id="sccb_gtm_container_id" value="<?php echo esc_attr( $options['gtm_container_id'] ); ?>" placeholder="GTM-XXXXXXX">
                            <p class="description"><?php esc_html_e( 'Je GTM Container ID (begint met GTM-). Laat leeg als je Google Site Kit gebruikt.', 'simple-cookie-consent-banner' ); ?></p>
                        </div>
                    </div>
                    
                    <div class="sccb-tracking-box">
                        <h4>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="#1877F2"><path d="M12 2C6.477 2 2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.879V14.89h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.989C18.343 21.129 22 16.99 22 12c0-5.523-4.477-10-10-10z"/></svg>
                            Meta Pixel (Facebook)
                            <span class="badge" style="background: #e53e3e;"><?php esc_html_e( 'Marketing', 'simple-cookie-consent-banner' ); ?></span>
                        </h4>
                        <div class="sccb-form-row">
                            <label for="sccb_meta_pixel_id"><?php esc_html_e( 'Pixel ID', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_meta_pixel_id" id="sccb_meta_pixel_id" value="<?php echo esc_attr( $options['meta_pixel_id'] ); ?>" placeholder="123456789012345">
                            <p class="description"><?php esc_html_e( 'Je Meta/Facebook Pixel ID (15-16 cijfers).', 'simple-cookie-consent-banner' ); ?></p>
                        </div>
                    </div>
                    
                    <div class="sccb-tracking-box">
                        <h4>
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="#FF3C00"><circle cx="12" cy="12" r="10"/></svg>
                            Hotjar
                            <span class="badge"><?php esc_html_e( 'Analytisch', 'simple-cookie-consent-banner' ); ?></span>
                        </h4>
                        <div class="sccb-form-row">
                            <label for="sccb_hotjar_site_id"><?php esc_html_e( 'Site ID', 'simple-cookie-consent-banner' ); ?></label>
                            <input type="text" name="sccb_hotjar_site_id" id="sccb_hotjar_site_id" value="<?php echo esc_attr( $options['hotjar_site_id'] ); ?>" placeholder="1234567">
                            <p class="description"><?php esc_html_e( 'Je Hotjar Site ID (te vinden in je Hotjar dashboard).', 'simple-cookie-consent-banner' ); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Step 4: Cookie Management -->
                <div class="sccb-step" data-step="4">
                    <h2><?php esc_html_e( 'Stap 4: Cookie beheer', 'simple-cookie-consent-banner' ); ?></h2>
                    
                    <div class="sccb-info-box">
                        <strong><?php esc_html_e( 'Automatische cookie detectie', 'simple-cookie-consent-banner' ); ?></strong><br>
                        <?php esc_html_e( 'Cookies worden automatisch gedetecteerd wanneer bezoekers je website bezoeken. Hier kun je ze aan de juiste categorie toewijzen.', 'simple-cookie-consent-banner' ); ?>
                    </div>
                    
                    <?php if ( empty( $discovered_cookies ) ) : ?>
                        <div class="sccb-no-cookies">
                            <span class="dashicons dashicons-info" style="font-size: 24px; width: 24px; height: 24px; margin-bottom: 10px;"></span><br>
                            <?php esc_html_e( 'Er zijn nog geen cookies gedetecteerd. Cookies worden automatisch ontdekt wanneer bezoekers je website bezoeken met de banner ingeschakeld.', 'simple-cookie-consent-banner' ); ?>
                        </div>
                    <?php else : ?>
                        <table class="sccb-cookie-table">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e( 'Cookie naam', 'simple-cookie-consent-banner' ); ?></th>
                                    <th><?php esc_html_e( 'Categorie', 'simple-cookie-consent-banner' ); ?></th>
                                    <th><?php esc_html_e( 'Beschrijving', 'simple-cookie-consent-banner' ); ?></th>
                                    <th><?php esc_html_e( 'Laatst gezien', 'simple-cookie-consent-banner' ); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ( $discovered_cookies as $cookie_name => $cookie_data ) : ?>
                                    <tr>
                                        <td><code><?php echo esc_html( $cookie_name ); ?></code></td>
                                        <td>
                                            <select name="sccb_cookie_category[<?php echo esc_attr( $cookie_name ); ?>]">
                                                <?php foreach ( $categories as $cat_key => $cat_data ) : ?>
                                                    <option value="<?php echo esc_attr( $cat_key ); ?>" <?php selected( $cookie_data['category'] ?? '', $cat_key ); ?>>
                                                        <?php echo esc_html( $cat_data['label'] ); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" name="sccb_cookie_description[<?php echo esc_attr( $cookie_name ); ?>]" value="<?php echo esc_attr( $cookie_data['description'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Optionele beschrijving...', 'simple-cookie-consent-banner' ); ?>">
                                        </td>
                                        <td><?php echo esc_html( $cookie_data['last_seen'] ?? '-' ); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
                
                <!-- Step 5: Styling -->
                <div class="sccb-step" data-step="5">
                    <h2><?php esc_html_e( 'Stap 5: Styling', 'simple-cookie-consent-banner' ); ?></h2>
                    
                    <div class="sccb-form-row">
                        <label><?php esc_html_e( 'Kleuren', 'simple-cookie-consent-banner' ); ?></label>
                        <div class="sccb-color-row">
                            <div class="sccb-color-item">
                                <label for="sccb_background_color"><?php esc_html_e( 'Achtergrond', 'simple-cookie-consent-banner' ); ?></label>
                                <div class="sccb-color-input-wrap">
                                    <input type="color" name="sccb_background_color" id="sccb_background_color" value="<?php echo esc_attr( $options['background_color'] ); ?>">
                                    <input type="text" value="<?php echo esc_attr( $options['background_color'] ); ?>" data-color-input="sccb_background_color" class="sccb-color-text">
                                </div>
                            </div>
                            
                            <div class="sccb-color-item">
                                <label for="sccb_text_color"><?php esc_html_e( 'Tekst', 'simple-cookie-consent-banner' ); ?></label>
                                <div class="sccb-color-input-wrap">
                                    <input type="color" name="sccb_text_color" id="sccb_text_color" value="<?php echo esc_attr( $options['text_color'] ); ?>">
                                    <input type="text" value="<?php echo esc_attr( $options['text_color'] ); ?>" data-color-input="sccb_text_color" class="sccb-color-text">
                                </div>
                            </div>
                            
                            <div class="sccb-color-item">
                                <label for="sccb_button_primary_color"><?php esc_html_e( 'Primaire knop', 'simple-cookie-consent-banner' ); ?></label>
                                <div class="sccb-color-input-wrap">
                                    <input type="color" name="sccb_button_primary_color" id="sccb_button_primary_color" value="<?php echo esc_attr( $options['button_primary_color'] ); ?>">
                                    <input type="text" value="<?php echo esc_attr( $options['button_primary_color'] ); ?>" data-color-input="sccb_button_primary_color" class="sccb-color-text">
                                </div>
                            </div>
                            
                            <div class="sccb-color-item">
                                <label for="sccb_button_secondary_color"><?php esc_html_e( 'Secundaire knop', 'simple-cookie-consent-banner' ); ?></label>
                                <div class="sccb-color-input-wrap">
                                    <input type="color" name="sccb_button_secondary_color" id="sccb_button_secondary_color" value="<?php echo esc_attr( $options['button_secondary_color'] ); ?>">
                                    <input type="text" value="<?php echo esc_attr( $options['button_secondary_color'] ); ?>" data-color-input="sccb_button_secondary_color" class="sccb-color-text">
                                </div>
                            </div>
                            
                            <div class="sccb-color-item">
                                <label for="sccb_accent_color"><?php esc_html_e( 'Accent', 'simple-cookie-consent-banner' ); ?></label>
                                <div class="sccb-color-input-wrap">
                                    <input type="color" name="sccb_accent_color" id="sccb_accent_color" value="<?php echo esc_attr( $options['accent_color'] ); ?>">
                                    <input type="text" value="<?php echo esc_attr( $options['accent_color'] ); ?>" data-color-input="sccb_accent_color" class="sccb-color-text">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="sccb-form-row-inline">
                        <div class="sccb-form-row">
                            <label for="sccb_position"><?php esc_html_e( 'Positie', 'simple-cookie-consent-banner' ); ?></label>
                            <select name="sccb_position" id="sccb_position">
                                <option value="bottom" <?php selected( $options['position'], 'bottom' ); ?>><?php esc_html_e( 'Onderkant', 'simple-cookie-consent-banner' ); ?></option>
                                <option value="top" <?php selected( $options['position'], 'top' ); ?>><?php esc_html_e( 'Bovenkant', 'simple-cookie-consent-banner' ); ?></option>
                                <option value="center" <?php selected( $options['position'], 'center' ); ?>><?php esc_html_e( 'Gecentreerd (modal)', 'simple-cookie-consent-banner' ); ?></option>
                            </select>
                        </div>
                        
                        <div class="sccb-form-row">
                            <label for="sccb_layout"><?php esc_html_e( 'Layout', 'simple-cookie-consent-banner' ); ?></label>
                            <select name="sccb_layout" id="sccb_layout">
                                <option value="bar" <?php selected( $options['layout'], 'bar' ); ?>><?php esc_html_e( 'Balk', 'simple-cookie-consent-banner' ); ?></option>
                                <option value="modal" <?php selected( $options['layout'], 'modal' ); ?>><?php esc_html_e( 'Modal/popup', 'simple-cookie-consent-banner' ); ?></option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Step 6: Summary -->
                <div class="sccb-step" data-step="6">
                    <h2><?php esc_html_e( 'Stap 6: Overzicht', 'simple-cookie-consent-banner' ); ?></h2>
                    <p><?php esc_html_e( 'Controleer je instellingen voordat je opslaat:', 'simple-cookie-consent-banner' ); ?></p>
                    
                    <table class="sccb-summary-table">
                        <tr>
                            <th><?php esc_html_e( 'Banner status', 'simple-cookie-consent-banner' ); ?></th>
                            <td id="summary-enabled"><?php echo $options['enabled'] ? '<span style="color:#48bb78;">✓ ' . esc_html__( 'Ingeschakeld', 'simple-cookie-consent-banner' ) . '</span>' : '<span style="color:#e53e3e;">✗ ' . esc_html__( 'Uitgeschakeld', 'simple-cookie-consent-banner' ) . '</span>'; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Google Analytics 4', 'simple-cookie-consent-banner' ); ?></th>
                            <td id="summary-ga4"><?php echo ! empty( $options['ga4_measurement_id'] ) ? '<span style="color:#48bb78;">✓ ' . esc_html( $options['ga4_measurement_id'] ) . '</span>' : '<span style="color:#718096;">—</span>'; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Google Tag Manager', 'simple-cookie-consent-banner' ); ?></th>
                            <td id="summary-gtm"><?php echo ! empty( $options['gtm_container_id'] ) ? '<span style="color:#48bb78;">✓ ' . esc_html( $options['gtm_container_id'] ) . '</span>' : '<span style="color:#718096;">—</span>'; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Meta Pixel', 'simple-cookie-consent-banner' ); ?></th>
                            <td id="summary-meta"><?php echo ! empty( $options['meta_pixel_id'] ) ? '<span style="color:#48bb78;">✓ ' . esc_html( $options['meta_pixel_id'] ) . '</span>' : '<span style="color:#718096;">—</span>'; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Hotjar', 'simple-cookie-consent-banner' ); ?></th>
                            <td id="summary-hotjar"><?php echo ! empty( $options['hotjar_site_id'] ) ? '<span style="color:#48bb78;">✓ ' . esc_html( $options['hotjar_site_id'] ) . '</span>' : '<span style="color:#718096;">—</span>'; ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Gedetecteerde cookies', 'simple-cookie-consent-banner' ); ?></th>
                            <td><?php echo count( $discovered_cookies ); ?> <?php esc_html_e( 'cookies', 'simple-cookie-consent-banner' ); ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Layout', 'simple-cookie-consent-banner' ); ?></th>
                            <td id="summary-layout"><?php echo $options['layout'] === 'modal' ? esc_html__( 'Modal/popup', 'simple-cookie-consent-banner' ) : esc_html__( 'Balk', 'simple-cookie-consent-banner' ); ?></td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e( 'Positie', 'simple-cookie-consent-banner' ); ?></th>
                            <td id="summary-position">
                                <?php
                                $positions = [
                                    'bottom' => __( 'Onderkant', 'simple-cookie-consent-banner' ),
                                    'top'    => __( 'Bovenkant', 'simple-cookie-consent-banner' ),
                                    'center' => __( 'Gecentreerd', 'simple-cookie-consent-banner' ),
                                ];
                                echo esc_html( $positions[ $options['position'] ] ?? $options['position'] );
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="sccb-wizard-nav">
                    <button type="button" class="button sccb-prev-btn" style="display: none;">
                        <span class="dashicons dashicons-arrow-left-alt" style="margin-top: 4px;"></span>
                        <?php esc_html_e( 'Vorige', 'simple-cookie-consent-banner' ); ?>
                    </button>
                    <button type="button" class="button button-primary sccb-next-btn">
                        <?php esc_html_e( 'Volgende', 'simple-cookie-consent-banner' ); ?>
                        <span class="dashicons dashicons-arrow-right-alt" style="margin-top: 4px;"></span>
                    </button>
                    <button type="submit" name="sccb_save_settings" class="button button-primary sccb-save-btn" style="display: none;">
                        <span class="dashicons dashicons-saved" style="margin-top: 4px;"></span>
                        <?php esc_html_e( 'Opslaan & Afronden', 'simple-cookie-consent-banner' ); ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    (function() {
        'use strict';
        
        var currentStep = 1;
        var totalSteps = 6;
        
        var steps = document.querySelectorAll('.sccb-step');
        var stepIndicators = document.querySelectorAll('.sccb-step-item');
        var prevBtn = document.querySelector('.sccb-prev-btn');
        var nextBtn = document.querySelector('.sccb-next-btn');
        var saveBtn = document.querySelector('.sccb-save-btn');
        
        function goToStep(step) {
            if (step < 1 || step > totalSteps) return;
            currentStep = step;
            updateStep();
        }
        
        function updateStep() {
            steps.forEach(function(step) {
                step.classList.remove('active');
                if (parseInt(step.dataset.step) === currentStep) {
                    step.classList.add('active');
                }
            });
            
            stepIndicators.forEach(function(indicator) {
                var stepNum = parseInt(indicator.dataset.step);
                indicator.classList.remove('active', 'completed');
                if (stepNum === currentStep) {
                    indicator.classList.add('active');
                } else if (stepNum < currentStep) {
                    indicator.classList.add('completed');
                }
            });
            
            prevBtn.style.display = currentStep === 1 ? 'none' : 'inline-flex';
            nextBtn.style.display = currentStep === totalSteps ? 'none' : 'inline-flex';
            saveBtn.style.display = currentStep === totalSteps ? 'inline-flex' : 'none';
            
            if (currentStep === totalSteps) {
                updateSummary();
            }
        }
        
        function updateSummary() {
            var enabled = document.querySelector('input[name="sccb_enabled"]').checked;
            var ga4 = document.getElementById('sccb_ga4_measurement_id').value;
            var gtm = document.getElementById('sccb_gtm_container_id').value;
            var meta = document.getElementById('sccb_meta_pixel_id').value;
            var hotjar = document.getElementById('sccb_hotjar_site_id').value;
            var layout = document.getElementById('sccb_layout').value;
            var position = document.getElementById('sccb_position').value;

            function setSummaryVal(id, value) {
                var el = document.getElementById(id);
                if (!el) return;
                el.textContent = '';
                var span = document.createElement('span');
                if (value) {
                    span.style.color = '#48bb78';
                    span.textContent = '\u2713 ' + value;
                } else {
                    span.style.color = '#718096';
                    span.textContent = '\u2014';
                }
                el.appendChild(span);
            }

            var enabledEl = document.getElementById('summary-enabled');
            if (enabledEl) {
                enabledEl.textContent = '';
                var span = document.createElement('span');
                span.style.color = enabled ? '#48bb78' : '#e53e3e';
                span.textContent = enabled ? '\u2713 Ingeschakeld' : '\u2717 Uitgeschakeld';
                enabledEl.appendChild(span);
            }
            setSummaryVal('summary-ga4', ga4);
            setSummaryVal('summary-gtm', gtm);
            setSummaryVal('summary-meta', meta);
            setSummaryVal('summary-hotjar', hotjar);
            document.getElementById('summary-layout').textContent = layout === 'modal' ? 'Modal/popup' : 'Balk';

            var positionLabels = { bottom: 'Onderkant', top: 'Bovenkant', center: 'Gecentreerd' };
            document.getElementById('summary-position').textContent = positionLabels[position] || position;
        }
        
        // Step indicator click handlers
        stepIndicators.forEach(function(indicator) {
            indicator.addEventListener('click', function() {
                var targetStep = parseInt(this.dataset.step);
                goToStep(targetStep);
            });
        });
        
        prevBtn.addEventListener('click', function() {
            if (currentStep > 1) {
                currentStep--;
                updateStep();
            }
        });
        
        nextBtn.addEventListener('click', function() {
            if (currentStep < totalSteps) {
                currentStep++;
                updateStep();
            }
        });
        
        // Color input sync
        document.querySelectorAll('input[type="color"]').forEach(function(colorInput) {
            var textInput = document.querySelector('[data-color-input="' + colorInput.id + '"]');
            if (textInput) {
                colorInput.addEventListener('input', function() {
                    textInput.value = colorInput.value;
                });
                textInput.addEventListener('input', function() {
                    if (/^#[0-9A-Fa-f]{6}$/.test(textInput.value)) {
                        colorInput.value = textInput.value;
                    }
                });
            }
        });
        
        updateStep();
    })();
    </script>
    <?php
}

/**
 * Enqueue frontend scripts and styles.
 */
function sccb_enqueue_frontend_assets(): void {
    if ( is_admin() ) {
        return;
    }
    
    $options = sccb_get_options();
    
    if ( empty( $options['enabled'] ) ) {
        return;
    }

    // Matomo consent is handled in sccb_add_consent_mode_defaults() via wp_head.
    
    wp_enqueue_style(
        'sccb-cookie-consent',
        SCCB_PLUGIN_URL . 'assets/css/sccb-cookie-consent.css',
        [],
        SCCB_VERSION
    );
    
    $custom_css = sprintf(
        ':root {
            --sccb-bg-color: %s;
            --sccb-text-color: %s;
            --sccb-btn-primary: %s;
            --sccb-btn-secondary: %s;
            --sccb-accent-color: %s;
        }',
        esc_attr( $options['background_color'] ),
        esc_attr( $options['text_color'] ),
        esc_attr( $options['button_primary_color'] ),
        esc_attr( $options['button_secondary_color'] ),
        esc_attr( $options['accent_color'] )
    );
    wp_add_inline_style( 'sccb-cookie-consent', $custom_css );
    
    $js_suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
    wp_enqueue_script(
        'sccb-cookie-consent',
        SCCB_PLUGIN_URL . 'assets/js/sccb-cookie-consent' . $js_suffix . '.js',
        [],
        SCCB_VERSION,
        true
    );
    
    // Get discovered cookies for frontend
    $discovered_cookies = sccb_get_discovered_cookies();
    $cookies_for_js     = [];
    foreach ( $discovered_cookies as $name => $data ) {
        $cookies_for_js[ $name ] = [
            'category'    => $data['category'] ?? 'functional',
            'description' => $data['description'] ?? '',
        ];
    }
    
    // Pass all necessary options to JavaScript
    wp_localize_script(
        'sccb-cookie-consent',
        'sccbConfig',
        [
            'restUrl'           => esc_url_raw( rest_url( 'sccb/v1/cookies' ) ),
            'nonce'             => wp_create_nonce( 'wp_rest' ),
            'tracking'          => [
                'ga4'     => $options['ga4_measurement_id'],
                'gtm'     => $options['gtm_container_id'],
                'meta'    => $options['meta_pixel_id'],
                'hotjar'  => $options['hotjar_site_id'],
            ],
            'categories'        => [
                'necessary'  => [
                    'label' => $options['category_necessary_label'],
                    'desc'  => $options['category_necessary_desc'],
                ],
                'functional' => [
                    'label' => $options['category_functional_label'],
                    'desc'  => $options['category_functional_desc'],
                ],
                'analytics'  => [
                    'label' => $options['category_analytics_label'],
                    'desc'  => $options['category_analytics_desc'],
                ],
                'marketing'  => [
                    'label' => $options['category_marketing_label'],
                    'desc'  => $options['category_marketing_desc'],
                ],
            ],
            'labels'            => [
                'acceptAll'      => $options['accept_all_label'],
                'acceptSelected' => $options['accept_selected_label'],
                'rejectAll'      => $options['reject_all_label'],
                'settings'       => $options['settings_label'],
            ],
            'layout'            => $options['layout'],
            'position'          => $options['position'],
            'discoveredCookies' => $cookies_for_js,
        ]
    );
}
add_action( 'wp_enqueue_scripts', 'sccb_enqueue_frontend_assets' );

/**
 * Add Google Consent Mode v2 defaults to head.
 * Must run before Site Kit or other GTM/GA implementations.
 */
function sccb_add_consent_mode_defaults(): void {
    $options = sccb_get_options();
    
    if ( empty( $options['enabled'] ) ) {
        return;
    }
    
    // Check if Site Kit is active or if user provided IDs manually, otherwise Consent Mode might not be needed
    // But generally safe to add if enabled.
    ?>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    
    // Default: denied
    gtag('consent', 'default', {
        'ad_storage': 'denied',
        'ad_user_data': 'denied',
        'ad_personalization': 'denied',
        'analytics_storage': 'denied',
        'functionality_storage': 'denied',
        'personalization_storage': 'denied',
        'security_storage': 'granted',
        'wait_for_update': 500
    });
    
    // Matomo / Piwik support: require consent before tracking
    window._paq = window._paq || [];
    window._paq.push(['requireConsent']);
    
    // Load stored consent immediately if available to prevent "glitch"
    (function() {
        try {
            var stored = localStorage.getItem('sccb_consent_v2');
            if (stored) {
                var consent = JSON.parse(stored);
                var mode = {
                    'ad_storage': consent.marketing ? 'granted' : 'denied',
                    'ad_user_data': consent.marketing ? 'granted' : 'denied',
                    'ad_personalization': consent.marketing ? 'granted' : 'denied',
                    'analytics_storage': consent.analytics ? 'granted' : 'denied',
                    'functionality_storage': consent.functional ? 'granted' : 'denied',
                    'personalization_storage': consent.functional ? 'granted' : 'denied',
                };
                gtag('consent', 'update', mode);
            }
        } catch(e) {}
    })();
    </script>
    <?php
}
add_action( 'wp_head', 'sccb_add_consent_mode_defaults', 1 );

/**
 * Shortcode to display a cookie settings link.
 *
 * Usage: [sccb_cookie_settings text="Cookie instellingen" class="my-custom-class" type="link"]
 *
 * @param array $atts Shortcode attributes.
 * @return string HTML output.
 */
function sccb_render_settings_shortcode( $atts ): string {
    $atts = shortcode_atts( [
        'text'  => __( 'Cookie instellingen', 'simple-cookie-consent-banner' ),
        'class' => 'sccb-settings-link',
        'type'  => 'link', // 'link' or 'button'
    ], $atts, 'sccb_cookie_settings' );
    
    $tag  = $atts['type'] === 'button' ? 'button' : 'a';
    $attr = $atts['type'] === 'button' ? 'type="button"' : 'href="#"';
    
    return sprintf(
        '<%1$s %2$s class="%3$s" onclick="event.preventDefault(); window.sccbConsent && window.sccbConsent.showSettings(); return false;">%4$s</%1$s>',
        esc_attr( $tag ),
        $attr, // Pre-defined safe string based on type
        esc_attr( $atts['class'] ),
        esc_html( $atts['text'] )
    );
}
add_shortcode( 'sccb_cookie_settings', 'sccb_render_settings_shortcode' );

/**
 * Output the cookie consent banner HTML in footer.
 */
function sccb_render_banner(): void {
    if ( is_admin() ) {
        return;
    }
    
    $options = sccb_get_options();
    
    if ( empty( $options['enabled'] ) ) {
        return;
    }
    
    $position_class = 'sccb-position-' . esc_attr( $options['position'] );
    $layout_class   = 'sccb-layout-' . esc_attr( $options['layout'] );
    ?>
    <!-- Cookie Consent Banner -->
    <div id="sccb-cookie-banner" class="sccb-cookie-banner <?php echo esc_attr( $position_class . ' ' . $layout_class ); ?>" role="dialog" aria-modal="true" aria-labelledby="sccb-banner-title" style="display: none;">
        <?php if ( $options['layout'] === 'modal' || $options['position'] === 'center' ) : ?>
        <div class="sccb-overlay"></div>
        <?php endif; ?>
        <div class="sccb-banner-container">
            <div class="sccb-banner-inner">
                <div class="sccb-banner-content">
                    <h2 id="sccb-banner-title" class="sccb-banner-title"><?php esc_html_e( 'Cookie instellingen', 'simple-cookie-consent-banner' ); ?></h2>
                    <p class="sccb-banner-text"><?php echo esc_html( $options['banner_text'] ); ?></p>
                    <?php if ( ! empty( $options['privacy_policy_url'] ) ) : ?>
                        <a href="<?php echo esc_url( $options['privacy_policy_url'] ); ?>" class="sccb-privacy-link" target="_blank" rel="noopener"><?php esc_html_e( 'Meer informatie', 'simple-cookie-consent-banner' ); ?></a>
                    <?php endif; ?>
                </div>
                
                <!-- Category toggles (shown in settings view) -->
                <div id="sccb-categories" class="sccb-categories" style="display: none;">
                    <?php
                    $discovered_cookies = sccb_get_discovered_cookies();
                    $category_configs   = [
                        'necessary'  => [
                            'label'    => $options['category_necessary_label'],
                            'desc'     => $options['category_necessary_desc'],
                            'required' => true,
                            'class'    => 'sccb-category-necessary',
                        ],
                        'functional' => [
                            'label'    => $options['category_functional_label'],
                            'desc'     => $options['category_functional_desc'],
                            'required' => false,
                            'class'    => '',
                        ],
                        'analytics'  => [
                            'label'    => $options['category_analytics_label'],
                            'desc'     => $options['category_analytics_desc'],
                            'required' => false,
                            'class'    => '',
                        ],
                        'marketing'  => [
                            'label'    => $options['category_marketing_label'],
                            'desc'     => $options['category_marketing_desc'],
                            'required' => false,
                            'class'    => '',
                        ],
                    ];
                    
                    foreach ( $category_configs as $cat_key => $cat_config ) :
                        // Count cookies in this category
                        $cat_cookies = array_filter( $discovered_cookies, function( $c ) use ( $cat_key ) {
                            return ( $c['category'] ?? '' ) === $cat_key;
                        } );
                        $cookie_count = count( $cat_cookies );
                    ?>
                    <div class="sccb-category <?php echo esc_attr( $cat_config['class'] ); ?>" data-category-section="<?php echo esc_attr( $cat_key ); ?>">
                        <div class="sccb-category-header">
                            <label class="sccb-category-toggle">
                                <input type="checkbox" data-category="<?php echo esc_attr( $cat_key ); ?>"<?php echo $cat_config['required'] ? ' checked disabled' : ''; ?>>
                                <span class="sccb-toggle-slider"></span>
                            </label>
                            <div class="sccb-category-info">
                                <span class="sccb-category-label"><?php echo esc_html( $cat_config['label'] ); ?></span>
                                <?php if ( $cat_config['required'] ) : ?>
                                    <span class="sccb-category-badge sccb-badge-required"><?php esc_html_e( 'Altijd actief', 'simple-cookie-consent-banner' ); ?></span>
                                <?php endif; ?>
                                <?php if ( $cookie_count > 0 ) : ?>
                                    <span class="sccb-cookie-count"><?php echo esc_html( $cookie_count ); ?> cookies</span>
                                <?php endif; ?>
                            </div>
                            <?php if ( $cookie_count > 0 ) : ?>
                            <button type="button" class="sccb-toggle-cookies-btn" data-toggle-category="<?php echo esc_attr( $cat_key ); ?>">
                                <?php esc_html_e( 'Toon cookies', 'simple-cookie-consent-banner' ); ?>
                            </button>
                            <?php endif; ?>
                        </div>
                        <p class="sccb-category-desc"><?php echo esc_html( $cat_config['desc'] ); ?></p>
                        
                        <!-- Per-cookie toggles (dynamically populated by JS, or pre-rendered) -->
                        <div class="sccb-cookie-list" style="display: none;">
                            <?php if ( $cookie_count > 0 ) : ?>
                                <?php foreach ( $cat_cookies as $cookie_name => $cookie_data ) : ?>
                                <div class="sccb-cookie-item">
                                    <div class="sccb-cookie-header">
                                        <label class="sccb-cookie-toggle">
                                            <input type="checkbox" data-cookie="<?php echo esc_attr( $cookie_name ); ?>" data-cookie-category="<?php echo esc_attr( $cat_key ); ?>"<?php echo $cat_config['required'] ? ' checked disabled' : ''; ?>>
                                            <span class="sccb-toggle-slider sccb-toggle-small"></span>
                                        </label>
                                        <div class="sccb-cookie-info">
                                            <code class="sccb-cookie-name"><?php echo esc_html( $cookie_name ); ?></code>
                                            <?php if ( ! empty( $cookie_data['description'] ) ) : ?>
                                                <span class="sccb-cookie-desc"><?php echo esc_html( $cookie_data['description'] ); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <p class="sccb-no-cookies-msg"><?php esc_html_e( 'Geen cookies in deze categorie', 'simple-cookie-consent-banner' ); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="sccb-banner-actions">
                    <div class="sccb-actions-main">
                        <button type="button" id="sccb-reject-all" class="sccb-btn sccb-btn-secondary">
                            <?php echo esc_html( $options['reject_all_label'] ); ?>
                        </button>
                        <button type="button" id="sccb-accept-all" class="sccb-btn sccb-btn-primary">
                            <?php echo esc_html( $options['accept_all_label'] ); ?>
                        </button>
                    </div>
                    <div class="sccb-actions-settings">
                        <button type="button" id="sccb-show-settings" class="sccb-btn sccb-btn-link">
                            <?php echo esc_html( $options['settings_label'] ); ?>
                        </button>
                        <button type="button" id="sccb-save-settings" class="sccb-btn sccb-btn-primary" style="display: none;">
                            <?php echo esc_html( $options['accept_selected_label'] ); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'sccb_render_banner' );

/**
 * Placeholder function for tracking scripts - maintained for backwards compatibility.
 */
function sccb_tracking_scripts_placeholder(): void {
    do_action( 'sccb_tracking_scripts' );
}

/**
 * Initialize the updater.
 */
function sccb_init_updater(): void {
    if ( ! class_exists( 'SCCB_Updater' ) ) {
        require_once SCCB_PLUGIN_DIR . 'includes/class-sccb-updater.php';
    }
    
    new SCCB_Updater( SCCB_UPDATE_URL, __FILE__, SCCB_VERSION );
}
add_action( 'plugins_loaded', 'sccb_init_updater' );
