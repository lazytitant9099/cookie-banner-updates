/**
 * Simple Cookie Consent Banner - Frontend JavaScript
 * Version 2.1.0 - Category + Per-Cookie consent
 * 
 * @package Simple_Cookie_Consent_Banner
 */

(function() {
    'use strict';

    // ==========================================================================
    // Configuration
    // ==========================================================================

    var CONSENT_KEY = 'sccb_consent_v2';
    var config = window.sccbConfig || {};
    
    // Default consent state
    var defaultConsent = {
        necessary: true,
        functional: false,
        analytics: false,
        marketing: false,
        cookies: {},
        timestamp: null
    };

    // ==========================================================================
    // DOM Elements
    // ==========================================================================

    var elements = {
        banner: null,
        overlay: null,
        categories: null,
        acceptAllBtn: null,
        rejectAllBtn: null,
        showSettingsBtn: null,
        saveSettingsBtn: null,
        categoryToggles: {},
        cookieToggles: {}
    };

    var settingsVisible = false;
    var cookieDetailsVisible = {};
    var cookieDiscoveryScheduled = false;

    var loadedScripts = {
        ga4: false,
        gtm: false,
        meta: false,
        hotjar: false
    };

    // ==========================================================================
    // Consent Storage
    // ==========================================================================

    function getConsent() {
        try {
            var stored = localStorage.getItem(CONSENT_KEY);
            if (stored) {
                var consent = JSON.parse(stored);
                consent.necessary = true;
                if (!consent.cookies) consent.cookies = {};
                return consent;
            }
            return null;
        } catch (e) {
            console.warn('[SCCB] Error reading consent:', e);
            return null;
        }
    }

    function setConsent(consent) {
        try {
            consent.necessary = true;
            consent.timestamp = new Date().toISOString();
            if (!consent.cookies) consent.cookies = {};
            localStorage.setItem(CONSENT_KEY, JSON.stringify(consent));
            return true;
        } catch (e) {
            console.warn('[SCCB] Error saving consent:', e);
            return false;
        }
    }

    function hasConsent() {
        return getConsent() !== null;
    }

    // ==========================================================================
    // Cookie-Level Consent Helpers
    // ==========================================================================

    /**
     * Check if a specific cookie is allowed.
     * First checks cookie-level preference, then falls back to category.
     */
    function isCookieAllowed(cookieName) {
        var consent = getConsent();
        if (!consent) return false;
        
        // Check cookie-level preference first
        if (consent.cookies && typeof consent.cookies[cookieName] !== 'undefined') {
            return consent.cookies[cookieName] === true;
        }
        
        // Fall back to category-level consent
        var cookieData = (config.discoveredCookies || {})[cookieName];
        if (cookieData && cookieData.category) {
            return consent[cookieData.category] === true;
        }
        
        return false;
    }

    /**
     * Get all allowed cookies.
     */
    function getAllowedCookies() {
        var consent = getConsent();
        if (!consent) return [];
        
        var allowed = [];
        var discovered = config.discoveredCookies || {};
        
        Object.keys(discovered).forEach(function(cookieName) {
            if (isCookieAllowed(cookieName)) {
                allowed.push(cookieName);
            }
        });
        
        return allowed;
    }

    /**
     * Get cookies by category with their consent status.
     */
    function getCookiesByCategory(category) {
        var discovered = config.discoveredCookies || {};
        var cookies = [];
        
        Object.keys(discovered).forEach(function(cookieName) {
            if (discovered[cookieName].category === category) {
                cookies.push({
                    name: cookieName,
                    description: discovered[cookieName].description || '',
                    allowed: isCookieAllowed(cookieName)
                });
            }
        });
        
        return cookies;
    }

    // ==========================================================================
    // Cookie Discovery
    // ==========================================================================

    function discoverCookies() {
        if (!config.restUrl) return;
        
        try {
            var cookieString = document.cookie;
            if (!cookieString) return;
            
            var cookies = cookieString.split(';').map(function(cookie) {
                return cookie.trim().split('=')[0];
            }).filter(function(name) {
                return name && name.length > 0;
            });
            
            if (cookies.length === 0) return;
            
            fetch(config.restUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': config.nonce || ''
                },
                body: JSON.stringify({ cookies: cookies })
            }).catch(function(e) {
                console.debug('[SCCB] Cookie discovery failed:', e);
            });
        } catch (e) {
            console.debug('[SCCB] Cookie discovery error:', e);
        }
    }

    function scheduleCookieDiscovery(delay) {
        if (cookieDiscoveryScheduled) {
            return;
        }
        cookieDiscoveryScheduled = true;
        setTimeout(discoverCookies, typeof delay === 'number' ? delay : 0);
    }

    // ==========================================================================
    // Tracking Scripts
    // ==========================================================================

    function initTrackingScripts(consent) {
        if (!consent) return;
        
        var tracking = config.tracking || {};
        
        if (consent.analytics) {
            // Matomo Consent Integration
            if (window._paq) {
                console.log('[SCCB] Enabling Matomo tracking');
                window._paq.push(['setConsentGiven']);
            }

            if (tracking.ga4 && !loadedScripts.ga4) {
                loadGA4(tracking.ga4);
                loadedScripts.ga4 = true;
            }
            if (tracking.gtm && !loadedScripts.gtm) {
                loadGTM(tracking.gtm);
                loadedScripts.gtm = true;
            }
            if (tracking.hotjar && !loadedScripts.hotjar) {
                loadHotjar(tracking.hotjar);
                loadedScripts.hotjar = true;
            }
        }
        
        if (consent.marketing) {
            if (tracking.meta && !loadedScripts.meta) {
                loadMetaPixel(tracking.meta);
                loadedScripts.meta = true;
            }
        }
        
        dispatchConsentEvent('sccb:tracking:init', consent);
    }

    function loadGA4(measurementId) {
        if (!measurementId) return;
        console.log('[SCCB] Loading Google Analytics 4:', measurementId);
        
        var script = document.createElement('script');
        script.async = true;
        script.src = 'https://www.googletagmanager.com/gtag/js?id=' + measurementId;
        document.head.appendChild(script);
        
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        window.gtag = gtag;
        gtag('js', new Date());
        gtag('config', measurementId, { 'anonymize_ip': true });
    }

    function loadGTM(containerId) {
        if (!containerId) return;
        console.log('[SCCB] Loading Google Tag Manager:', containerId);
        
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', containerId);
    }

    function loadMetaPixel(pixelId) {
        if (!pixelId) return;
        console.log('[SCCB] Loading Meta Pixel:', pixelId);
        
        !function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
            };
            if (!f._fbq) f._fbq = n;
            n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = [];
            t = b.createElement(e); t.async = !0; t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s);
        }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
        
        fbq('init', pixelId);
        fbq('track', 'PageView');
    }

    function loadHotjar(siteId) {
        if (!siteId) return;
        console.log('[SCCB] Loading Hotjar:', siteId);
        
        (function(h, o, t, j, a, r) {
            h.hj = h.hj || function() { (h.hj.q = h.hj.q || []).push(arguments); };
            h._hjSettings = { hjid: siteId, hjsv: 6 };
            a = o.getElementsByTagName('head')[0];
            r = o.createElement('script'); r.async = 1;
            r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv;
            a.appendChild(r);
        })(window, document, 'https://static.hotjar.com/c/hotjar-', '.js?sv=');
    }

    /**
     * Update Google Consent Mode v2
     */
    function updateConsentMode(consent) {
        if (typeof window.gtag === 'function') {
            var mode = {
                'ad_storage': consent.marketing ? 'granted' : 'denied',
                'ad_user_data': consent.marketing ? 'granted' : 'denied',
                'ad_personalization': consent.marketing ? 'granted' : 'denied',
                'analytics_storage': consent.analytics ? 'granted' : 'denied',
                'functionality_storage': consent.functional ? 'granted' : 'denied',
                'personalization_storage': consent.functional ? 'granted' : 'denied'
            };
            window.gtag('consent', 'update', mode);
            console.log('[SCCB] Updated Consent Mode:', mode);
        }
        
        // Update Matomo
        updateMatomoConsent(consent);
    }

    /**
     * Update Matomo / Piwik Consent
     */
    function updateMatomoConsent(consent) {
        if (typeof window._paq !== 'undefined') {
            if (consent.analytics) {
                window._paq.push(['setConsentGiven']);
                // window._paq.push(['rememberConsentGiven']); // Optional: lets Matomo set its own cookie
                console.log('[SCCB] Matomo consent granted');
            } else {
                window._paq.push(['forgetConsentGiven']);
                console.log('[SCCB] Matomo consent revoked');
            }
        }
    }

    // ==========================================================================
    // Event Dispatching
    // ==========================================================================

    function dispatchConsentEvent(eventName, detail) {
        if (typeof CustomEvent === 'function') {
            document.dispatchEvent(new CustomEvent(eventName, { detail: detail }));
        }
    }

    // ==========================================================================
    // Dynamic Cookie Toggles UI
    // ==========================================================================

    function renderCookieToggles() {
        var discovered = config.discoveredCookies || {};
        var categories = ['necessary', 'functional', 'analytics', 'marketing'];
        var consent = getConsent() || defaultConsent;
        
        categories.forEach(function(category) {
            var categoryEl = elements.banner.querySelector('[data-category-section="' + category + '"]');
            if (!categoryEl) return;
            
            var cookiesContainer = categoryEl.querySelector('.sccb-cookie-list');
            if (!cookiesContainer) return;
            
            // Clear existing
            cookiesContainer.innerHTML = '';
            elements.cookieToggles[category] = [];
            
            // Get cookies for this category
            var categoryCookies = [];
            Object.keys(discovered).forEach(function(cookieName) {
                if (discovered[cookieName].category === category) {
                    categoryCookies.push({
                        name: cookieName,
                        description: discovered[cookieName].description || ''
                    });
                }
            });
            
            if (categoryCookies.length === 0) {
                cookiesContainer.innerHTML = '<p class="sccb-no-cookies-msg">Geen cookies in deze categorie</p>';
                return;
            }
            
            categoryCookies.forEach(function(cookie) {
                var isNecessary = category === 'necessary';
                var cookieConsent = consent.cookies && typeof consent.cookies[cookie.name] !== 'undefined'
                    ? consent.cookies[cookie.name]
                    : consent[category];
                
                var cookieEl = document.createElement('div');
                cookieEl.className = 'sccb-cookie-item';
                cookieEl.innerHTML = 
                    '<div class="sccb-cookie-header">' +
                        '<label class="sccb-cookie-toggle">' +
                            '<input type="checkbox" data-cookie="' + escapeHtml(cookie.name) + '" data-cookie-category="' + category + '"' +
                            (cookieConsent || isNecessary ? ' checked' : '') +
                            (isNecessary ? ' disabled' : '') + '>' +
                            '<span class="sccb-toggle-slider sccb-toggle-small"></span>' +
                        '</label>' +
                        '<div class="sccb-cookie-info">' +
                            '<code class="sccb-cookie-name">' + escapeHtml(cookie.name) + '</code>' +
                            (cookie.description ? '<span class="sccb-cookie-desc">' + escapeHtml(cookie.description) + '</span>' : '') +
                        '</div>' +
                    '</div>';
                
                cookiesContainer.appendChild(cookieEl);
                
                var toggle = cookieEl.querySelector('input[data-cookie]');
                if (toggle) {
                    elements.cookieToggles[category].push(toggle);
                }
            });
        });
    }

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function toggleCookieDetails(category) {
        var section = elements.banner.querySelector('[data-category-section="' + category + '"]');
        if (!section) return;
        
        var cookieList = section.querySelector('.sccb-cookie-list');
        var toggleBtn = section.querySelector('.sccb-toggle-cookies-btn');
        
        if (!cookieList) return;
        
        cookieDetailsVisible[category] = !cookieDetailsVisible[category];
        
        if (cookieDetailsVisible[category]) {
            cookieList.style.display = 'block';
            if (toggleBtn) toggleBtn.textContent = 'Verberg cookies';
            section.classList.add('sccb-cookies-expanded');
        } else {
            cookieList.style.display = 'none';
            if (toggleBtn) toggleBtn.textContent = 'Toon cookies';
            section.classList.remove('sccb-cookies-expanded');
        }
    }

    // ==========================================================================
    // Banner UI
    // ==========================================================================

    function showBanner() {
        if (!elements.banner) return;
        
        elements.banner.style.display = 'block';
        elements.banner.offsetHeight;
        elements.banner.classList.add('sccb-visible');
        elements.banner.setAttribute('aria-hidden', 'false');
    }

    function hideBanner() {
        if (!elements.banner) return;
        
        // Accessibility: Release focus from banner elements before hiding
        if (elements.banner.contains(document.activeElement)) {
            document.activeElement.blur();
        }

        elements.banner.classList.remove('sccb-visible');
        elements.banner.setAttribute('aria-hidden', 'true');
        
        setTimeout(function() {
            elements.banner.style.display = 'none';
        }, 300);
    }

    function showSettings() {
        if (!elements.categories) return;

        // Ensure banner is visible
        showBanner();
        
        settingsVisible = true;
        elements.categories.style.display = 'block';
        
        if (elements.showSettingsBtn) elements.showSettingsBtn.style.display = 'none';
        if (elements.saveSettingsBtn) elements.saveSettingsBtn.style.display = 'inline-flex';
        
        elements.banner.classList.add('sccb-settings-visible');
        
        var consent = getConsent() || defaultConsent;
        updateCategoryToggles(consent);
        renderCookieToggles();
    }

    function hideSettings() {
        if (!elements.categories) return;
        
        settingsVisible = false;
        elements.categories.style.display = 'none';
        
        if (elements.showSettingsBtn) elements.showSettingsBtn.style.display = 'inline-flex';
        if (elements.saveSettingsBtn) elements.saveSettingsBtn.style.display = 'none';
        
        elements.banner.classList.remove('sccb-settings-visible');
    }

    function updateCategoryToggles(consent) {
        Object.keys(elements.categoryToggles).forEach(function(category) {
            var toggle = elements.categoryToggles[category];
            if (toggle && category !== 'necessary') {
                toggle.checked = consent[category] || false;
            }
        });
    }

    function getConsentFromToggles() {
        var consent = {
            necessary: true,
            functional: false,
            analytics: false,
            marketing: false,
            cookies: {}
        };
        
        // Get category toggles
        Object.keys(elements.categoryToggles).forEach(function(category) {
            var toggle = elements.categoryToggles[category];
            if (toggle && category !== 'necessary') {
                consent[category] = toggle.checked;
            }
        });
        
        // Get per-cookie toggles
        Object.keys(elements.cookieToggles).forEach(function(category) {
            var toggles = elements.cookieToggles[category];
            if (toggles && toggles.length) {
                toggles.forEach(function(toggle) {
                    var cookieName = toggle.getAttribute('data-cookie');
                    if (cookieName) {
                        consent.cookies[cookieName] = toggle.checked;
                    }
                });
            }
        });
        
        return consent;
    }

    // Category toggle changes should update all cookies in that category
    function handleCategoryToggleChange(category, checked) {
        var toggles = elements.cookieToggles[category];
        if (toggles && toggles.length) {
            toggles.forEach(function(toggle) {
                if (!toggle.disabled) {
                    toggle.checked = checked;
                }
            });
        }
    }

    // ==========================================================================
    // Cookie Scrubbing (Cleaning up cookies after consent revocation)
    // ==========================================================================

    function deleteCookie(name) {
        var hostname = window.location.hostname;
        var domains = [
            hostname,
            '.' + hostname,
            hostname.substring(hostname.lastIndexOf('.', hostname.lastIndexOf('.') - 1) + 1)
        ];
        var paths = ['/', window.location.pathname];

        domains.forEach(function(domain) {
            paths.forEach(function(path) {
                document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=' + path + '; domain=' + domain + ';';
                document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=' + path + ';';
            });
        });
    }

    function scrubCookies(consent) {
        console.log('[SCCB] Scrubbing cookies based on new consent...');
        
        // 1. Scrub known tracking patterns if category is denied
        var cookies = document.cookie.split(';');
        
        if (!consent.analytics) {
            var analyticsPatterns = ['_ga', '_gid', '_gat', '_hj', '__hstc', 'hubspot', 'matomo', 'pk_'];
            cookies.forEach(function(c) {
                var name = c.trim().split('=')[0];
                analyticsPatterns.forEach(function(prefix) {
                    if (name.indexOf(prefix) !== -1) {
                        console.log('[SCCB] Deleting analytics cookie:', name);
                        deleteCookie(name);
                    }
                });
            });
        }
        
        if (!consent.marketing) {
            var marketingPatterns = ['_fbp', '_fbc', '_gcl', 'ads', 'cto_'];
            cookies.forEach(function(c) {
                var name = c.trim().split('=')[0];
                marketingPatterns.forEach(function(prefix) {
                    if (name.indexOf(prefix) !== -1) {
                        console.log('[SCCB] Deleting marketing cookie:', name);
                        deleteCookie(name);
                    }
                });
            });
        }
        
        // 2. Scrub specifically discovered cookies if their category is denied
        var discovered = config.discoveredCookies || {};
        Object.keys(discovered).forEach(function(name) {
            var data = discovered[name];
            var category = data.category;
            
            // If category denied AND cookie not explicitly allowed
            if (category !== 'necessary' && !consent[category] && (!consent.cookies || consent.cookies[name] !== true)) {
                 console.log('[SCCB] Deleting discovered cookie:', name);
                 deleteCookie(name);
            }
        });
    }

    // ==========================================================================
    // Consent Handlers
    // ==========================================================================

    function handleAcceptAll() {
        var consent = {
            necessary: true,
            functional: true,
            analytics: true,
            marketing: true,
            cookies: {}
        };
        
        // Set all discovered cookies to true
        var discovered = config.discoveredCookies || {};
        Object.keys(discovered).forEach(function(cookieName) {
            consent.cookies[cookieName] = true;
        });
        
        setConsent(consent);
        hideBanner();
        initTrackingScripts(consent);
        updateConsentMode(consent);
        scheduleCookieDiscovery(500);
        
        dispatchConsentEvent('sccb:consent:accepted', consent);
        dispatchConsentEvent('sccb:consent:changed', consent);
        
        console.log('[SCCB] All cookies accepted');
    }

    function handleRejectAll() {
        var previousConsent = getConsent();
        var consent = {
            necessary: true,
            functional: false,
            analytics: false,
            marketing: false,
            cookies: {}
        };
        
        // Set all non-necessary cookies to false, necessary to true
        var discovered = config.discoveredCookies || {};
        Object.keys(discovered).forEach(function(cookieName) {
            var category = discovered[cookieName].category;
            consent.cookies[cookieName] = category === 'necessary';
        });
        
        // Scrub cookies before saving new state (visually cleaner)
        scrubCookies(consent);

        setConsent(consent);
        hideBanner();
        updateConsentMode(consent);
        scheduleCookieDiscovery(500);
        
        dispatchConsentEvent('sccb:consent:rejected', consent);
        dispatchConsentEvent('sccb:consent:changed', consent);
        
        console.log('[SCCB] Optional cookies rejected');

        // Reload if we previously had consent to ensure scripts are stopped
        if (previousConsent && (previousConsent.analytics || previousConsent.marketing)) {
            console.log('[SCCB] Reloading page to clear scripts...');
            window.location.reload();
        }
    }

    function handleSaveSettings() {
        var previousConsent = getConsent();
        var consent = getConsentFromToggles();
        
        // Scrub cookies that are now denied
        scrubCookies(consent);

        setConsent(consent);
        hideBanner();
        initTrackingScripts(consent);
        updateConsentMode(consent);
        scheduleCookieDiscovery(500);
        
        dispatchConsentEvent('sccb:consent:saved', consent);
        dispatchConsentEvent('sccb:consent:changed', consent);
        
        console.log('[SCCB] Cookie preferences saved:', consent);

        // Reload if specific categories were revoked
        if (previousConsent) {
            var analyticsRevoked = previousConsent.analytics && !consent.analytics;
            var marketingRevoked = previousConsent.marketing && !consent.marketing;
            
            if (analyticsRevoked || marketingRevoked) {
                console.log('[SCCB] Reloading page to clear revoked scripts...');
                window.location.reload();
            }
        }
    }

    // ==========================================================================
    // Initialization
    // ==========================================================================

    function initElements() {
        elements.banner = document.getElementById('sccb-cookie-banner');
        if (!elements.banner) return false;
        
        elements.overlay = elements.banner.querySelector('.sccb-overlay');
        elements.categories = document.getElementById('sccb-categories');
        elements.acceptAllBtn = document.getElementById('sccb-accept-all');
        elements.rejectAllBtn = document.getElementById('sccb-reject-all');
        elements.showSettingsBtn = document.getElementById('sccb-show-settings');
        elements.saveSettingsBtn = document.getElementById('sccb-save-settings');
        
        // Get category toggles
        var toggles = elements.banner.querySelectorAll('[data-category]');
        toggles.forEach(function(toggle) {
            var category = toggle.getAttribute('data-category');
            if (category) {
                elements.categoryToggles[category] = toggle;
            }
        });
        
        return true;
    }

    function bindEvents() {
        if (elements.acceptAllBtn) {
            elements.acceptAllBtn.addEventListener('click', handleAcceptAll);
        }
        
        if (elements.rejectAllBtn) {
            elements.rejectAllBtn.addEventListener('click', handleRejectAll);
        }
        
        if (elements.showSettingsBtn) {
            elements.showSettingsBtn.addEventListener('click', showSettings);
        }
        
        if (elements.saveSettingsBtn) {
            elements.saveSettingsBtn.addEventListener('click', handleSaveSettings);
        }
        
        // Category toggle change handlers
        Object.keys(elements.categoryToggles).forEach(function(category) {
            var toggle = elements.categoryToggles[category];
            if (toggle && category !== 'necessary') {
                toggle.addEventListener('change', function() {
                    handleCategoryToggleChange(category, toggle.checked);
                });
            }
        });
        
        // Toggle cookie details buttons
        elements.banner.querySelectorAll('.sccb-toggle-cookies-btn').forEach(function(btn) {
            var category = btn.getAttribute('data-toggle-category');
            if (category) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    toggleCookieDetails(category);
                });
            }
        });
        
        // Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && settingsVisible) {
                hideSettings();
            }
        });
    }

    function init() {
        if (!initElements()) return;
        
        bindEvents();
        
        var consent = getConsent();
        
        if (consent === null) {
            showBanner();
        } else {
            initTrackingScripts(consent);
            scheduleCookieDiscovery(2000);
        }
    }

    // ==========================================================================
    // Public API
    // ==========================================================================

    window.sccbConsent = {
        /**
         * Get current consent object.
         */
        getConsent: function() {
            return getConsent();
        },
        
        /**
         * Check if a category is allowed.
         */
        isAllowed: function(category) {
            var consent = getConsent();
            if (!consent) return category === 'necessary';
            return consent[category] === true;
        },
        
        /**
         * Check if a specific cookie is allowed.
         * @param {string} cookieName The cookie name to check.
         * @return {boolean}
         */
        isCookieAllowed: function(cookieName) {
            return isCookieAllowed(cookieName);
        },
        
        /**
         * Get all allowed cookie names.
         * @return {Array<string>}
         */
        getAllowedCookies: function() {
            return getAllowedCookies();
        },
        
        /**
         * Get cookies for a specific category with their status.
         * @param {string} category Category name.
         * @return {Array<{name: string, description: string, allowed: boolean}>}
         */
        getCookiesByCategory: function(category) {
            return getCookiesByCategory(category);
        },
        
        /**
         * Set consent for a specific cookie.
         * @param {string} cookieName Cookie name.
         * @param {boolean} allowed Whether the cookie is allowed.
         */
        setCookieConsent: function(cookieName, allowed) {
            var consent = getConsent() || Object.assign({}, defaultConsent);
            if (!consent.cookies) consent.cookies = {};
            consent.cookies[cookieName] = allowed;
            setConsent(consent);
            dispatchConsentEvent('sccb:consent:changed', consent);
        },
        
        /**
         * Reset consent and show banner.
         */
        reset: function() {
            try {
                localStorage.removeItem(CONSENT_KEY);
            } catch (e) {}
            hideSettings();
            showBanner();
            cookieDiscoveryScheduled = false;
        },
        
        acceptAll: function() { handleAcceptAll(); },
        rejectAll: function() { handleRejectAll(); },
        
        updateConsent: function(newConsent) {
            var consent = Object.assign({}, defaultConsent, newConsent);
            consent.necessary = true;
            if (!consent.cookies) consent.cookies = {};
            setConsent(consent);
            initTrackingScripts(consent);
            dispatchConsentEvent('sccb:consent:changed', consent);
        },
        
        showBanner: showBanner,
        hideBanner: hideBanner,
        showSettings: showSettings
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
