<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'SCCB_Updater' ) ) {
    class SCCB_Updater {
        private $plugin_slug;
        private $plugin_basename;
        private $remote_url;
        private $version;
        private $cache_key;
        private $cache_ttl = 43200; // 12 uur cache

        public function __construct( $remote_url, $plugin_file, $version ) {
            $this->remote_url = $remote_url;
            $this->plugin_basename = plugin_basename( $plugin_file );
            $this->plugin_slug = sanitize_title( basename( dirname( $this->plugin_basename ) ) );
            $this->version = $version;
            $this->cache_key = 'sccb_updater_' . md5( $this->plugin_basename );

            // WordPress builds plugin updates via pre_set_site_transient_update_plugins.
            add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_update' ] );
            // Keep compatibility with environments that rely on the later transient filter.
            add_filter( 'site_transient_update_plugins', [ $this, 'check_update' ] );
            add_filter( 'plugins_api', [ $this, 'plugin_info' ], 20, 3 );
            add_action( 'upgrader_process_complete', [ $this, 'clear_cache_after_update' ], 10, 2 );
        }

        public function check_update( $transient ) {
            if ( ! is_object( $transient ) ) {
                $transient = new stdClass();
            }

            if ( $this->is_forced_check() ) {
                delete_transient( $this->cache_key );
            }

            if ( empty( $transient->checked ) || ! is_array( $transient->checked ) ) {
                return $transient;
            }

            if ( ! isset( $transient->checked[ $this->plugin_basename ] ) ) {
                return $transient;
            }

            $remote = $this->get_remote_info();

            if ( $remote && isset( $remote->version ) && version_compare( $this->version, (string) $remote->version, '<' ) ) {
                $res = new stdClass();
                $res->slug = $this->plugin_slug;
                $res->plugin = $this->plugin_basename;
                $res->new_version = $remote->version;
                $res->url = $remote->homepage ?? '';
                $res->package = $remote->download_url; // URL naar ZIP bestand
                
                $transient->response[ $this->plugin_basename ] = $res;
            } elseif ( isset( $transient->response[ $this->plugin_basename ] ) ) {
                unset( $transient->response[ $this->plugin_basename ] );
            }

            return $transient;
        }

        private function is_forced_check(): bool {
            if ( ! isset( $_GET['force-check'] ) ) {
                return false;
            }

            return sanitize_text_field( wp_unslash( $_GET['force-check'] ) ) === '1';
        }

        public function plugin_info( $res, $action, $args ) {
            if ( $action !== 'plugin_information' ) {
                return $res;
            }

            if ( ! isset( $args->slug ) || $args->slug !== $this->plugin_slug ) {
                return $res;
            }

            $remote = $this->get_remote_info();

            if ( ! $remote ) {
                return $res;
            }

            $res = new stdClass();
            $res->name = $remote->name ?? '';
            $res->slug = $this->plugin_slug;
            $res->version = $remote->version ?? '';
            $res->tested = $remote->tested ?? '';
            $res->requires = $remote->requires ?? '';
            $res->author = $remote->author ?? '';
            $res->author_profile = $remote->author_profile ?? '';
            $res->download_link = $remote->download_url ?? '';
            $res->trunk = $remote->download_url ?? '';
            $res->requires_php = $remote->requires_php ?? '';
            $res->last_updated = $remote->last_updated ?? '';
            
            $res->sections = [
                'description' => $remote->sections->description ?? '',
                'installation' => $remote->sections->installation ?? '',
                'changelog' => $remote->sections->changelog ?? '',
            ];
            
            if ( ! empty( $remote->banners ) ) {
                $res->banners = (array) $remote->banners;
            }

            return $res;
        }

        public function clear_cache_after_update( $upgrader_object, $options ) {
            if ( empty( $options['action'] ) || $options['action'] !== 'update' ) {
                return;
            }

            if ( empty( $options['type'] ) || $options['type'] !== 'plugin' ) {
                return;
            }

            delete_transient( $this->cache_key );
        }

        private function get_remote_info() {
            // Probeer eerst uit cache te halen
            $remote = get_transient( $this->cache_key );
            
            if ( false === $remote ) {
                $request = wp_remote_get( $this->remote_url, [
                    'timeout' => 10,
                    'headers' => [
                        'Accept' => 'application/json'
                    ]
                ] );

                if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) !== 200 ) {
                    return false;
                }

                $body = wp_remote_retrieve_body( $request );
                $remote = json_decode( $body );
                
                if ( $remote ) {
                    set_transient( $this->cache_key, $remote, $this->cache_ttl );
                }
            }
            
            return $remote;
        }
    }
}
