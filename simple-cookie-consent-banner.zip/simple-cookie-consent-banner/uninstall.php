<?php
/**
 * Uninstall handler for Simple Cookie Consent Banner.
 *
 * Cleans up all plugin data when the plugin is deleted via the WordPress admin.
 *
 * @package Simple_Cookie_Consent_Banner
 */

// If uninstall is not called from WordPress, exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin options.
delete_option( 'sccb_options' );
delete_option( 'sccb_db_version' );
delete_option( 'sccb_discovered_cookies' );
delete_option( 'sccb_discovered_cookies_backup' );

// Delete transients.
delete_transient( 'sccb_activation_redirect' );

// Clean up updater and rate-limit transients.
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_sccb_%' OR option_name LIKE '_transient_timeout_sccb_%'" );

// Drop the custom database table.
$table_name = $wpdb->prefix . 'sccb_cookies';
$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" );
